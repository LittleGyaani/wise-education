(function( $ ){
	'use strict';

	/***** Menu Tab *****/
	$( function() {
      $( "#tabs" ).tabs();
   } );
	/***** End Menu Tab *****/

})(jQuery); 	
