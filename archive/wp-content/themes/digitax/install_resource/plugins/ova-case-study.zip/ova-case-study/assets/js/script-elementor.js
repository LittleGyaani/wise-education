(function($){
	"use strict";

	$(window).on('elementor/frontend/init', function () {

		/* Element */
      elementorFrontend.hooks.addAction('frontend/element_ready/ovacs_case_study.default', function(){

      });

   });
})(jQuery);
