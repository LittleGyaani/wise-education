<?php

if( !defined( 'ABSPATH' ) ) exit();

global $post;

?>
<div class="ovapo_metabox">

</div>

<?php wp_nonce_field( 'ovapo_nonce', 'ovapo_nonce' ); ?>